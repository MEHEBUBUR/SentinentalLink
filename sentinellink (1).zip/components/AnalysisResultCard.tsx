import React from 'react';
import { AnalysisResult, RiskLevel } from '../types';
import RiskMeter from './RiskMeter';
import { ShieldCheck, ShieldAlert, ShieldX, FileSearch, Terminal, ArrowLeft } from 'lucide-react';

interface AnalysisResultCardProps {
  result: AnalysisResult;
  onReset: () => void;
}

const AnalysisResultCard: React.FC<AnalysisResultCardProps> = ({ result, onReset }) => {
  
  const getSeverityConfig = (level: RiskLevel) => {
    switch (level) {
      case RiskLevel.SAFE:
        return {
          icon: <ShieldCheck className="w-8 h-8 text-emerald-400" />,
          color: "text-emerald-400",
          borderColor: "border-emerald-500/20",
          bgColor: "bg-emerald-500/5",
          badge: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20",
          label: "LINK LOOKS SAFE"
        };
      case RiskLevel.SUSPICIOUS:
        return {
          icon: <ShieldAlert className="w-8 h-8 text-amber-400" />,
          color: "text-amber-400",
          borderColor: "border-amber-500/20",
          bgColor: "bg-amber-500/5",
          badge: "bg-amber-500/10 text-amber-400 border-amber-500/20",
          label: "USE CAUTION"
        };
      case RiskLevel.MALICIOUS:
        return {
          icon: <ShieldX className="w-8 h-8 text-red-500" />,
          color: "text-red-500",
          borderColor: "border-red-500/20",
          bgColor: "bg-red-500/5",
          badge: "bg-red-500/10 text-red-500 border-red-500/20",
          label: "DANGEROUS LINK"
        };
      default:
        return {
          icon: <FileSearch className="w-8 h-8 text-slate-400" />,
          color: "text-slate-400",
          borderColor: "border-slate-500/20",
          bgColor: "bg-slate-500/5",
          badge: "bg-slate-500/10 text-slate-400 border-slate-500/20",
          label: "UNCERTAIN"
        };
    }
  };

  const config = getSeverityConfig(result.riskLevel);

  return (
    <div className="w-full max-w-6xl mx-auto animate-fade-in">
      <div className="mb-6 flex items-center justify-between">
        <button 
          onClick={onReset}
          className="flex items-center gap-2 text-sm text-slate-400 hover:text-white transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Check Another Link</span>
        </button>
        <span className="text-xs text-slate-500 font-mono">ID: {crypto.randomUUID().split('-')[0]}</span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left Col: Status & Score */}
        <div className={`col-span-1 rounded-xl border ${config.borderColor} ${config.bgColor} p-6 flex flex-col items-center text-center`}>
          <div className="mb-4 p-3 bg-brand-950 rounded-full border border-brand-800">
            {config.icon}
          </div>
          <h2 className={`text-xl font-bold tracking-tight ${config.color} mb-1`}>{config.label}</h2>
          <p className="text-slate-400 text-xs font-mono break-all mb-8">{result.url}</p>
          
          <div className="w-40 h-40">
             <RiskMeter score={result.riskScore} level={result.riskLevel} />
          </div>
          
          <div className="mt-8 w-full border-t border-brand-800/50 pt-4">
            <div className="flex justify-between items-center text-sm">
               <span className="text-slate-500">Threat Type</span>
               <span className="text-white font-medium">{result.threatType}</span>
            </div>
          </div>
        </div>

        {/* Right Col: Details */}
        <div className="col-span-1 lg:col-span-2 space-y-6">
          
          {/* Executive Summary */}
          <div className="bg-brand-900 border border-brand-800 rounded-xl p-6">
            <h3 className="text-sm font-semibold text-slate-200 uppercase tracking-wider mb-4 flex items-center gap-2">
              <FileSearch className="w-4 h-4 text-brand-accent" />
              Summary
            </h3>
            <p className="text-slate-300 leading-relaxed text-sm">
              {result.explanation}
            </p>
          </div>

          {/* Technical Indicators */}
          <div className="bg-brand-900 border border-brand-800 rounded-xl p-6 flex-grow">
            <h3 className="text-sm font-semibold text-slate-200 uppercase tracking-wider mb-4 flex items-center gap-2">
              <Terminal className="w-4 h-4 text-brand-accent" />
              Technical Details
            </h3>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {result.technicalFlags.length > 0 ? (
                result.technicalFlags.map((flag, index) => (
                  <div key={index} className="flex items-center gap-2 p-3 rounded bg-brand-950 border border-brand-800">
                    <div className={`w-1.5 h-1.5 rounded-full ${result.riskLevel === RiskLevel.SAFE ? 'bg-emerald-500' : 'bg-red-500'}`} />
                    <span className="text-xs text-slate-300 font-mono">{flag}</span>
                  </div>
                ))
              ) : (
                <div className="col-span-2 text-slate-500 text-sm italic py-2">No obvious problems found.</div>
              )}
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};

export default AnalysisResultCard;