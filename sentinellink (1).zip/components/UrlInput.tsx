import React, { useState } from 'react';
import { Search, Globe, AlertTriangle } from 'lucide-react';

interface UrlInputProps {
  onAnalyze: (url: string) => void;
  isLoading: boolean;
}

const UrlInput: React.FC<UrlInputProps> = ({ onAnalyze, isLoading }) => {
  const [url, setUrl] = useState('');
  const [error, setError] = useState('');

  const validateAndSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!url.trim()) {
      setError('Please enter a link to check.');
      return;
    }

    let formattedUrl = url.trim();
    if (!/^https?:\/\//i.test(formattedUrl)) {
      formattedUrl = 'https://' + formattedUrl;
    }

    try {
      new URL(formattedUrl);
      onAnalyze(formattedUrl);
    } catch (err) {
      setError('The link does not look right. Please check it.');
    }
  };

  return (
    <div className="w-full max-w-2xl mx-auto relative z-20">
      <form onSubmit={validateAndSubmit} className="relative group">
        
        {/* Input Container */}
        <div className={`
          relative flex items-center bg-brand-900 border transition-all duration-300 rounded-lg overflow-hidden shadow-2xl
          ${error ? 'border-red-900/50 shadow-red-900/10' : 'border-brand-700 group-hover:border-brand-600 shadow-brand-950/50'}
        `}>
          
          <div className="pl-5 pr-3 text-slate-500">
            <Globe className="w-5 h-5" />
          </div>

          <input
            type="text"
            value={url}
            onChange={(e) => {
              setUrl(e.target.value);
              if (error) setError('');
            }}
            disabled={isLoading}
            placeholder="Paste a link here to check if it is safe..."
            className="w-full py-4 bg-transparent text-white placeholder-slate-500 focus:outline-none font-mono text-sm"
          />

          <button
            type="submit"
            disabled={isLoading}
            className={`
              m-1 px-6 py-2.5 rounded-md font-medium text-sm transition-all duration-200 flex items-center gap-2
              ${isLoading 
                ? 'bg-brand-800 text-slate-400 cursor-wait' 
                : 'bg-brand-accent hover:bg-brand-accentHover text-white shadow-lg shadow-brand-accent/20'
              }
            `}
          >
            {isLoading ? (
              <>
                <div className="w-3 h-3 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                <span>Checking...</span>
              </>
            ) : (
              <>
                <span>Check Link</span>
                <Search className="w-3 h-3" />
              </>
            )}
          </button>
        </div>
      </form>
      
      {error && (
        <div className="absolute top-full left-0 mt-2 flex items-center gap-2 text-red-400 text-xs font-medium animate-fade-in">
          <AlertTriangle className="w-3 h-3" />
          <span>{error}</span>
        </div>
      )}
    </div>
  );
};

export default UrlInput;