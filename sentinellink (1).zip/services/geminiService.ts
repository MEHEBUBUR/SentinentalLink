import { GoogleGenAI, Type } from "@google/genai";
import { AnalysisResult, RiskLevel } from "../types";

const parseRiskLevel = (score: number): RiskLevel => {
  if (score < 20) return RiskLevel.SAFE;
  if (score < 60) return RiskLevel.SUSPICIOUS;
  return RiskLevel.MALICIOUS;
};

export const analyzeUrlWithGemini = async (url: string): Promise<AnalysisResult> => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    // We use gemini-3-flash-preview for fast, reasoning-capable analysis
    const modelId = "gemini-3-flash-preview";
    
    const systemInstruction = `
      You are a helpful cybersecurity expert. Your job is to check links (URLs) to see if they are safe or dangerous.
      
      Analyze the provided URL for:
      1. Fake websites trying to steal passwords (phishing).
      2. Links that download viruses (malware).
      3. Weird looking web addresses that try to trick users (like g0ogle.com).
      
      Provide a risk score from 0 (Safe) to 100 (Very Dangerous).
      
      IMPORTANT: Write the explanation in simple, plain English that anyone can understand. Avoid complex technical jargon.
    `;

    const response = await ai.models.generateContent({
      model: modelId,
      contents: `Analyze this URL: ${url}`,
      config: {
        systemInstruction: systemInstruction,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            riskScore: {
              type: Type.NUMBER,
              description: "A score from 0 to 100 indicating danger level.",
            },
            threatType: {
              type: Type.STRING,
              description: "The type of threat (e.g., Phishing, Virus, Safe, Suspicious).",
            },
            explanation: {
              type: Type.STRING,
              description: "A simple, easy-to-understand explanation of why this link is safe or dangerous.",
            },
            technicalFlags: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "List of specific reasons (e.g., 'Hidden characters', 'Suspicious name').",
            },
          },
          required: ["riskScore", "threatType", "explanation", "technicalFlags"],
        },
      },
    });

    const jsonText = response.text;
    if (!jsonText) {
      throw new Error("No response from AI");
    }

    const data = JSON.parse(jsonText);

    return {
      url,
      riskScore: data.riskScore,
      riskLevel: parseRiskLevel(data.riskScore),
      threatType: data.threatType,
      explanation: data.explanation,
      technicalFlags: data.technicalFlags,
      analyzedAt: new Date().toISOString(),
    };

  } catch (error) {
    console.error("Gemini Analysis Error:", error);
    // Fallback in case of API error to prevent app crash, 
    // though in a real app we might want to show the error explicitly.
    return {
      url,
      riskScore: 0,
      riskLevel: RiskLevel.UNKNOWN,
      threatType: "Analysis Failed",
      explanation: "Unable to connect to the server. Please check your internet connection.",
      technicalFlags: ["Connection Error"],
      analyzedAt: new Date().toISOString(),
    };
  }
};