import React, { useState } from 'react';
import { ShieldCheck, Lock, Globe, History, ChevronRight } from 'lucide-react';
import UrlInput from './components/UrlInput';
import AnalysisResultCard from './components/AnalysisResultCard';
import { analyzeUrlWithGemini } from './services/geminiService';
import { AnalysisResult, HistoryItem } from './types';

function App() {
  const [currentResult, setCurrentResult] = useState<AnalysisResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [viewHistory, setViewHistory] = useState(false);

  const handleAnalyze = async (url: string) => {
    setIsLoading(true);
    setCurrentResult(null);
    setViewHistory(false);

    try {
      const result = await analyzeUrlWithGemini(url);
      setCurrentResult(result);
      
      // Add to history
      setHistory(prev => [
        { ...result, id: crypto.randomUUID() },
        ...prev
      ].slice(0, 10)); // Keep last 10
    } catch (error) {
      console.error("Analysis failed", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleReset = () => {
    setCurrentResult(null);
  };

  return (
    <div className="min-h-screen bg-brand-950 text-slate-200 font-sans flex flex-col selection:bg-brand-accent selection:text-white">
      
      {/* Abstract Professional Background */}
      <div className="fixed inset-0 z-0 pointer-events-none">
        <div className="absolute top-0 left-0 w-full h-[500px] bg-gradient-to-b from-brand-900 to-brand-950" />
        <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-brand-accent/5 rounded-full blur-[120px]" />
      </div>

      {/* Navigation Bar */}
      <header className="relative z-10 border-b border-brand-800 bg-brand-950/80 backdrop-blur-md sticky top-0">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => setCurrentResult(null)}>
            <div className="w-8 h-8 bg-brand-accent rounded flex items-center justify-center">
              <ShieldCheck className="text-white w-5 h-5" />
            </div>
            <div>
              <h1 className="text-lg font-bold tracking-tight text-white leading-none">SentinelLink</h1>
              <span className="text-[10px] text-brand-400 uppercase tracking-widest font-semibold">Link Safety Checker</span>
            </div>
          </div>
          
          <button 
            onClick={() => setViewHistory(!viewHistory)}
            className="flex items-center gap-2 px-3 py-1.5 rounded-md text-slate-400 hover:text-white hover:bg-brand-800 transition-all text-sm font-medium"
          >
            <History className="w-4 h-4" />
            <span>Scan History</span>
          </button>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="relative z-10 flex-grow flex flex-col px-4 sm:px-6 lg:px-8 py-12">
        
        {viewHistory ? (
           <div className="max-w-5xl mx-auto w-full animate-fade-in">
              <div className="flex justify-between items-center mb-8 border-b border-brand-800 pb-4">
                <h2 className="text-xl font-semibold text-white">Previous Scans</h2>
                <button 
                  onClick={() => setViewHistory(false)}
                  className="text-sm text-brand-accent hover:text-brand-accentHover font-medium flex items-center gap-1"
                >
                  Back to Dashboard <ChevronRight className="w-4 h-4" />
                </button>
              </div>
              
              <div className="bg-brand-900 border border-brand-800 rounded-lg overflow-hidden">
                {history.length === 0 ? (
                  <div className="p-12 text-center">
                    <History className="w-12 h-12 text-brand-700 mx-auto mb-4" />
                    <p className="text-brand-400">No scan history available.</p>
                  </div>
                ) : (
                  <table className="w-full text-left text-sm text-slate-400">
                    <thead className="bg-brand-950 text-slate-200 font-medium">
                      <tr>
                        <th className="px-6 py-3">Time</th>
                        <th className="px-6 py-3">Link</th>
                        <th className="px-6 py-3">Status</th>
                        <th className="px-6 py-3 text-right">Score</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-brand-800">
                      {history.map((item) => (
                        <tr key={item.id} className="hover:bg-brand-800/50 transition-colors">
                          <td className="px-6 py-4 font-mono text-xs">{new Date(item.analyzedAt).toLocaleString()}</td>
                          <td className="px-6 py-4 truncate max-w-xs text-slate-200">{item.url}</td>
                          <td className="px-6 py-4">
                             <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium 
                              ${item.riskLevel === 'SAFE' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 
                                item.riskLevel === 'SUSPICIOUS' ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20' : 'bg-red-500/10 text-red-400 border border-red-500/20'}`}>
                              {item.riskLevel}
                            </span>
                          </td>
                          <td className="px-6 py-4 text-right font-mono">{item.riskScore}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}
              </div>
           </div>
        ) : (
          <>
            {!currentResult ? (
              <div className="flex-grow flex flex-col items-center justify-center -mt-10">
                <div className="text-center mb-10 max-w-3xl mx-auto space-y-6">
                  <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-brand-900 border border-brand-700 text-xs font-medium text-brand-accent">
                    <span className="relative flex h-2 w-2">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-brand-accent opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-2 w-2 bg-brand-accent"></span>
                    </span>
                    System Ready
                  </div>
                  
                  <h2 className="text-4xl md:text-5xl font-bold text-white tracking-tight leading-tight">
                    Professional <br/>
                    <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-indigo-500">
                      Link Scanner
                    </span>
                  </h2>
                  <p className="text-slate-400 text-lg max-w-2xl mx-auto font-light">
                    Check if a link is safe before you click. We use smart AI to find phishing, viruses, and fake websites instantly.
                  </p>
                </div>

                <UrlInput onAnalyze={handleAnalyze} isLoading={isLoading} />

                <div className="mt-20 grid grid-cols-1 md:grid-cols-3 gap-6 w-full max-w-5xl">
                   <div className="p-6 rounded-xl bg-brand-900/50 border border-brand-800 hover:border-brand-700 transition-colors">
                      <div className="w-10 h-10 bg-brand-950 rounded-lg flex items-center justify-center mb-4 border border-brand-800">
                        <Lock className="w-5 h-5 text-emerald-400" />
                      </div>
                      <h3 className="text-white font-semibold mb-2">Strict Safety Check</h3>
                      <p className="text-sm text-slate-400">We check every link carefully to make sure it is safe.</p>
                   </div>
                   <div className="p-6 rounded-xl bg-brand-900/50 border border-brand-800 hover:border-brand-700 transition-colors">
                      <div className="w-10 h-10 bg-brand-950 rounded-lg flex items-center justify-center mb-4 border border-brand-800">
                        <Globe className="w-5 h-5 text-blue-400" />
                      </div>
                      <h3 className="text-white font-semibold mb-2">Smart Detection</h3>
                      <p className="text-sm text-slate-400">We look for known bad links and dangerous patterns.</p>
                   </div>
                   <div className="p-6 rounded-xl bg-brand-900/50 border border-brand-800 hover:border-brand-700 transition-colors">
                      <div className="w-10 h-10 bg-brand-950 rounded-lg flex items-center justify-center mb-4 border border-brand-800">
                        <ShieldCheck className="w-5 h-5 text-indigo-400" />
                      </div>
                      <h3 className="text-white font-semibold mb-2">AI Analysis</h3>
                      <p className="text-sm text-slate-400">Finds hidden tricks that other scanners might miss.</p>
                   </div>
                </div>
              </div>
            ) : (
              <AnalysisResultCard result={currentResult} onReset={handleReset} />
            )}
          </>
        )}

      </main>

      {/* Professional Footer */}
      <footer className="relative z-10 border-t border-brand-800 bg-brand-950 py-8 mt-auto">
        <div className="max-w-7xl mx-auto px-4 flex flex-col items-center justify-center text-center">
          
          <div className="mb-6 space-y-2">
            <p className="text-slate-300 text-sm font-light">
              Website created by
            </p>
            <h3 className="text-lg font-medium text-white tracking-wide">
              Mehebubur Rahman <span className="text-brand-600 mx-2">&</span> Rudradev Choudhury
            </h3>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-1 sm:gap-2 text-sm text-slate-400 mt-2">
              <span>Students of Class 12</span>
              <span className="hidden sm:block">•</span>
              <a 
                href="https://barpeta.kvs.ac.in/en/" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-brand-accent hover:text-white transition-colors hover:underline flex items-center gap-1"
              >
                PM SHRI Kendriya Vidyalaya, Barpeta
                <ChevronRight className="w-3 h-3" />
              </a>
            </div>
          </div>

          <div className="w-full max-w-xs h-px bg-brand-800 my-4"></div>

          <p className="text-brand-600 text-xs">
            © {new Date().getFullYear()} SentinelLink. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
}

export default App;